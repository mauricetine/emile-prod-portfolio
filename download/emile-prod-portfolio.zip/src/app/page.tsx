'use client'

import { useState, useEffect, useRef } from 'react'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  Palette, 
  FileImage, 
  Camera, 
  Frame, 
  Monitor, 
  Video, 
  Phone, 
  Mail, 
  Instagram,
  Menu,
  X,
  ChevronDown,
  Send,
  Eye,
  Sparkles,
  Zap,
  Award,
  CheckCircle
} from 'lucide-react'

// Services data
const services = [
  {
    id: 1,
    icon: Palette,
    title: "Création de Logos",
    description: "Identités visuelles d'entreprises uniques et mémorables. Chaque logo est conçu pour refléter l'essence de votre marque avec créativité et professionnalisme.",
    color: "from-red-500 to-red-600"
  },
  {
    id: 2,
    icon: FileImage,
    title: "Flyers & Affiches",
    description: "Supports événementiels percutants pour concerts, soirées et promotions. Designs impactants qui captent l'attention et transmettent votre message.",
    color: "from-gray-700 to-gray-900"
  },
  {
    id: 3,
    icon: Camera,
    title: "Retouche Photo",
    description: "Montages et retouches professionnelles de haute qualité. Sublimation de vos images avec des techniques avancées de post-production.",
    color: "from-red-500 to-red-600"
  },
  {
    id: 4,
    icon: Frame,
    title: "Tableaux Muraux",
    description: "Créations personnalisées pour décoration intérieure. Œuvres uniques qui transforment vos espaces en galeries d'art personnelles.",
    color: "from-gray-700 to-gray-900"
  },
  {
    id: 5,
    icon: Monitor,
    title: "Design Graphique",
    description: "Visuels pour réseaux sociaux, bannières et posts Instagram. Contenus visuels optimisés pour maximiser votre engagement en ligne.",
    color: "from-red-500 to-red-600"
  },
  {
    id: 6,
    icon: Video,
    title: "Vidéo & Motion",
    description: "Création vidéo et montage pour contenus digitaux. Productions dynamiques qui donnent vie à vos idées avec style et professionnalisme.",
    color: "from-gray-700 to-gray-900"
  }
]

// Portfolio items
const portfolioItems = [
  {
    id: 1,
    image: "/portfolio-1.png",
    title: "Logo Design",
    category: "Identité Visuelle",
    description: "Création de logo moderne et minimaliste"
  },
  {
    id: 2,
    image: "/portfolio-2.png",
    title: "Flyer Événement",
    category: "Print Design",
    description: "Flyer concert avec typographie dynamique"
  },
  {
    id: 3,
    image: "/portfolio-3.png",
    title: "Retouche Portrait",
    category: "Photo Editing",
    description: "Retouche beauté professionnelle"
  },
  {
    id: 4,
    image: "/portfolio-4.png",
    title: "Art Mural",
    category: "Décoration",
    description: "Création artistique pour intérieur"
  },
  {
    id: 5,
    image: "/portfolio-5.png",
    title: "Social Media Kit",
    category: "Digital Design",
    description: "Pack complet réseaux sociaux"
  },
  {
    id: 6,
    image: "/portfolio-6.png",
    title: "Motion Design",
    category: "Vidéo",
    description: "Animation graphique promotionnelle"
  }
]

// Stats
const stats = [
  { number: "150+", label: "Projets Réalisés" },
  { number: "80+", label: "Clients Satisfaits" },
  { number: "5+", label: "Années d'Expérience" },
  { number: "100%", label: "Engagement Qualité" }
]

export default function Portfolio() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')
  const [isScrolled, setIsScrolled] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)

  // Handle scroll effects
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
      
      // Update active section based on scroll position
      const sections = ['home', 'services', 'portfolio', 'contact']
      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setSubmitSuccess(true)
    setFormData({ name: '', email: '', message: '' })
    
    setTimeout(() => setSubmitSuccess(false), 3000)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div 
              className="flex items-center gap-3 cursor-pointer"
              onClick={() => scrollToSection('home')}
            >
              <div className="relative w-12 h-12">
                <Image
                  src="/emile-prod-logo.jpeg"
                  alt="Emile Prod Logo"
                  fill
                  className="object-contain"
                />
              </div>
              <span className="text-xl font-bold tracking-tight">
                <span className="text-black">Emile</span>
                <span className="text-red-600 ml-1">Prod</span>
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {[
                { id: 'home', label: 'Accueil' },
                { id: 'services', label: 'Services' },
                { id: 'portfolio', label: 'Portfolio' },
                { id: 'contact', label: 'Contact' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`relative text-sm font-medium transition-colors duration-300 ${
                    activeSection === item.id 
                      ? 'text-red-600' 
                      : 'text-gray-700 hover:text-red-600'
                  }`}
                >
                  {item.label}
                  {activeSection === item.id && (
                    <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-red-600 rounded-full" />
                  )}
                </button>
              ))}
              <Button 
                className="bg-red-600 hover:bg-red-700 text-white px-6"
                onClick={() => scrollToSection('contact')}
              >
                <Send className="w-4 h-4 mr-2" />
                Devis Gratuit
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-gray-700 hover:text-red-600 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden absolute top-20 left-0 right-0 bg-white shadow-lg transition-all duration-300 ${
          isMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}>
          <div className="px-4 py-6 space-y-4">
            {[
              { id: 'home', label: 'Accueil' },
              { id: 'services', label: 'Services' },
              { id: 'portfolio', label: 'Portfolio' },
              { id: 'contact', label: 'Contact' }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full text-left py-2 text-lg font-medium transition-colors ${
                  activeSection === item.id ? 'text-red-600' : 'text-gray-700'
                }`}
              >
                {item.label}
              </button>
            ))}
            <Button 
              className="w-full bg-red-600 hover:bg-red-700 text-white mt-4"
              onClick={() => scrollToSection('contact')}
            >
              <Send className="w-4 h-4 mr-2" />
              Devis Gratuit
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center hero-pattern overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 right-10 w-72 h-72 bg-red-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-gray-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div className="space-y-8 animate-fade-in-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-50 border border-red-100 rounded-full">
                <Sparkles className="w-4 h-4 text-red-600" />
                <span className="text-sm font-medium text-red-700">Design Graphique Créatif</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-gray-900">Donnez Vie à Vos</span>
                <br />
                <span className="gradient-text">Idées Créatives</span>
              </h1>
              
              <p className="text-lg text-gray-600 max-w-xl leading-relaxed">
                Studio de design graphique spécialisé dans la création d&apos;identités visuelles 
                uniques. De la conception de logos à la production vidéo, nous transformons 
                votre vision en réalité visuelle impactante.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  size="lg"
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg btn-primary"
                  onClick={() => scrollToSection('portfolio')}
                >
                  <Eye className="w-5 h-5 mr-2" />
                  Voir Mes Travaux
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="px-8 py-6 text-lg border-2 border-gray-900 text-gray-900 hover:bg-gray-900 hover:text-white"
                  onClick={() => scrollToSection('services')}
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Mes Services
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-3xl font-bold text-red-600">{stat.number}</div>
                    <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative flex justify-center animate-fade-in-up stagger-2">
              <div className="relative w-80 h-80 sm:w-96 sm:h-96">
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-gray-900/20 rounded-3xl transform rotate-6" />
                <div className="absolute inset-0 bg-white rounded-3xl shadow-2xl overflow-hidden">
                  <Image
                    src="/emile-prod-logo.jpeg"
                    alt="Emile Prod Logo"
                    fill
                    className="object-contain p-8"
                  />
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg animate-float">
                <Palette className="w-10 h-10 text-white" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gray-900 rounded-2xl flex items-center justify-center shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                <Video className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>

          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
            <span className="text-sm text-gray-400">Défiler</span>
            <ChevronDown className="w-5 h-5 text-red-600" />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-50 border border-red-100 rounded-full mb-4">
              <Award className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Expertise</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Ce Que Je Fais
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Des services de design graphique complets pour donner vie à vos projets créatifs
            </p>
            <div className="section-divider mx-auto mt-6" />
          </div>

          {/* Services Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card 
                key={service.id}
                className="service-card bg-white border-0 shadow-lg overflow-hidden group"
              >
                <CardContent className="p-8">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-sm font-bold text-red-600 mb-2">
                    0{service.id}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-50 border border-red-100 rounded-full mb-4">
              <Eye className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Galerie</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Mes Réalisations
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Découvrez une sélection de mes travaux créatifs récents
            </p>
            <div className="section-divider mx-auto mt-6" />
          </div>

          {/* Portfolio Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {portfolioItems.map((item, index) => (
              <div 
                key={item.id}
                className="portfolio-item relative aspect-square rounded-2xl overflow-hidden shadow-lg cursor-pointer group"
              >
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="portfolio-overlay absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex flex-col justify-end p-6">
                  <span className="text-red-400 text-sm font-medium mb-1">
                    {item.category}
                  </span>
                  <h3 className="text-white text-xl font-bold mb-1">
                    {item.title}
                  </h3>
                  <p className="text-gray-300 text-sm">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* View More Button */}
          <div className="text-center mt-12">
            <Button 
              size="lg"
              className="bg-red-600 hover:bg-red-700 text-white px-8 btn-primary"
            >
              Voir Plus de Projets
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Me Section */}
      <section className="py-24 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                Pourquoi <span className="text-red-500">Emile Prod</span> ?
              </h2>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Passionné par le design graphique depuis plus de 5 ans, je m&apos;engage à créer 
                des visuels qui non seulement répondent à vos attentes, mais les dépassent. 
                Chaque projet est une nouvelle opportunité de créer quelque chose d&apos;unique.
              </p>
              
              <div className="space-y-4">
                {[
                  "Designs personnalisés et originaux",
                  "Respect des délais garantis",
                  "Communication fluide et réactive",
                  "Révisions incluses dans chaque projet",
                  "Tarifs compétitifs et transparents"
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-gray-200">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="relative aspect-square rounded-2xl overflow-hidden">
                  <Image
                    src="/portfolio-1.png"
                    alt="Portfolio Work"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="relative aspect-video rounded-2xl overflow-hidden">
                  <Image
                    src="/portfolio-3.png"
                    alt="Portfolio Work"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="relative aspect-video rounded-2xl overflow-hidden">
                  <Image
                    src="/portfolio-2.png"
                    alt="Portfolio Work"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="relative aspect-square rounded-2xl overflow-hidden">
                  <Image
                    src="/portfolio-4.png"
                    alt="Portfolio Work"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-50 border border-red-100 rounded-full mb-4">
              <Send className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Contact</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Travaillons Ensemble
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Vous avez un projet en tête ? Contactez-moi pour en discuter !
            </p>
            <div className="section-divider mx-auto mt-6" />
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">
                  Informations de Contact
                </h3>
                
                <div className="space-y-6">
                  <a 
                    href="tel:+221783269623"
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-red-50 transition-colors group"
                  >
                    <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Téléphone</div>
                      <div className="font-semibold text-gray-900">+221 78 326 96 23</div>
                    </div>
                  </a>
                  
                  <a 
                    href="mailto:emilesoumare2001@gmail.com"
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-red-50 transition-colors group"
                  >
                    <div className="w-12 h-12 bg-gray-900 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Email</div>
                      <div className="font-semibold text-gray-900">emilesoumare2001@gmail.com</div>
                    </div>
                  </a>
                  
                  <a 
                    href="https://instagram.com" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-red-50 transition-colors group"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Instagram className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Instagram</div>
                      <div className="font-semibold text-gray-900">@emile.prod</div>
                    </div>
                  </a>
                </div>
              </div>
              
              {/* Availability */}
              <div className="bg-gradient-to-br from-red-600 to-red-700 rounded-2xl p-8 text-white">
                <h3 className="text-xl font-bold mb-4">Disponibilité</h3>
                <p className="text-red-100 mb-6">
                  Disponible pour des projets freelance, des collaborations créatives 
                  et des missions de design graphique.
                </p>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-sm">Actuellement disponible pour de nouveaux projets</span>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Envoyez un Message
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Votre Nom
                  </label>
                  <Input
                    type="text"
                    placeholder="Entrez votre nom"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="h-12"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Votre Email
                  </label>
                  <Input
                    type="email"
                    placeholder="Entrez votre email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="h-12"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Votre Message
                  </label>
                  <Textarea
                    placeholder="Décrivez votre projet..."
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="min-h-[150px] resize-none"
                    required
                  />
                </div>
                
                <Button 
                  type="submit"
                  className="w-full h-12 bg-red-600 hover:bg-red-700 text-white text-lg btn-primary"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Envoi en cours...
                    </div>
                  ) : submitSuccess ? (
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      Message Envoyé !
                    </div>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Envoyer le Message
                    </>
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12 items-center">
            {/* Logo */}
            <div className="flex flex-col items-center md:items-start">
              <div className="flex items-center gap-3 mb-4">
                <div className="relative w-12 h-12">
                  <Image
                    src="/emile-prod-logo.jpeg"
                    alt="Emile Prod Logo"
                    fill
                    className="object-contain"
                  />
                </div>
                <span className="text-xl font-bold">
                  <span className="text-white">Emile</span>
                  <span className="text-red-500 ml-1">Prod</span>
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                Studio de design graphique créatif
              </p>
            </div>
            
            {/* Quick Links */}
            <div className="flex justify-center gap-8">
              {['Accueil', 'Services', 'Portfolio', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-gray-400 hover:text-red-500 transition-colors text-sm"
                >
                  {item}
                </button>
              ))}
            </div>
            
            {/* Social Links */}
            <div className="flex items-center justify-center md:justify-end gap-4">
              <a 
                href="mailto:emilesoumare2001@gmail.com"
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a 
                href="tel:+221783269623"
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <Phone className="w-5 h-5" />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gradient-to-br hover:from-purple-600 hover:to-pink-500 transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Divider */}
          <div className="border-t border-gray-800 my-8" />
          
          {/* Copyright */}
          <div className="text-center text-gray-500 text-sm">
            <p>© {new Date().getFullYear()} Emile Prod. Tous droits réservés.</p>
            <p className="mt-2">
              Qualité – Créativité – Rapidité
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
