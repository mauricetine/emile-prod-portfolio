import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Optimisations pour la production
  reactStrictMode: true,
  
  // Configuration des images
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
    unoptimized: false,
  },
  
  // Ignore les erreurs TypeScript en build (à activer si nécessaire)
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
